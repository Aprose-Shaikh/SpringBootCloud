package com.aci.payon.rest.microservices.limitsservices.controllor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aci.payon.rest.microservices.limitsservices.Configuration;
import com.aci.payon.rest.microservices.limitsservices.bean.LimitConfiguration;

@RestController
public class LimitControllor {
	@Autowired
	Configuration configuration; 
	@GetMapping (path="/limits")
	public LimitConfiguration getLimit() {
		return new LimitConfiguration(configuration.getMaximum(),configuration.getMinimum());
	}

}
